import type { Selectable } from "kysely";
import type { SobreTable } from "./sobre-table";

export type Sobre = Selectable<SobreTable>;
