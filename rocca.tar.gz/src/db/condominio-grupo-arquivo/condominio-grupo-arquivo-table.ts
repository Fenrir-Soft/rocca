import type { ArquivoTable } from "../arquivo-table";

export interface CondominioGrupoArquivoTable extends ArquivoTable {
    condominiogrupo_id: number;
}
