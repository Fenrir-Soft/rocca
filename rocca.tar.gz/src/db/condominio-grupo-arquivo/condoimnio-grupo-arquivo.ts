import type { Selectable } from "kysely";
import type { CondominioGrupoArquivoTable } from "./condominio-grupo-arquivo-table";

export type CondominioGrupoArquivo = Selectable<CondominioGrupoArquivoTable>;
