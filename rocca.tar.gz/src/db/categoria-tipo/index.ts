export * from "./categoria-tipo";
export * from "./categoria-tipo-table";
