import type { DefaultTable } from "../default-table";

export interface TrajetoriaTable extends DefaultTable {
    imagem: string
    titulo: string
    subtitulo: string
    video: string
}
