import type { Selectable } from "kysely";
import type { RedeSocialTable } from "./rede-social-table";

export type RedeSocial = Selectable<RedeSocialTable>;
