import type { DefaultTable } from "../default-table";

export interface ImovelComplementoTable extends DefaultTable {
    codigo_imovel: number;
}
