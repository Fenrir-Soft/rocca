import type { DefaultTable } from "../default-table";

export interface ImovelTagTable extends DefaultTable {
    imovelcomplemento_id: number;
    tagimovel_id: number;
}
