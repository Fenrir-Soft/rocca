export interface PoliticaPrivacidadeTable {
    texto: string;
}
