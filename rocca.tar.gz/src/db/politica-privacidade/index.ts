export * from "./politica-privacidade";
export * from "./politica-privacidade-table";
