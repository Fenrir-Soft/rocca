import type { Selectable } from "kysely";
import type { TagImovelTable } from "./tag-imovel-table";

export type TagImovel = Selectable<TagImovelTable>;
