import type { DefaultTable } from "../default-table";

export interface TagImovelTable extends DefaultTable {
    titulo: string;
    cor: string;
    background: string;
}
