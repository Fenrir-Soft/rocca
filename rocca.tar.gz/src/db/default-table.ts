export interface DefaultTable {
    id: number;
    deleted: boolean;
    ordenamento: number;
    created: string;
    modified: string;
    uuid: string;
}
