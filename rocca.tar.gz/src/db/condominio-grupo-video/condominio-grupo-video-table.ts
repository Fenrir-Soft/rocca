import type { VideoTable } from "../video-table";

export interface CondominioGrupoVideoTable extends VideoTable {
    condominiogrupo_id: number;
}
