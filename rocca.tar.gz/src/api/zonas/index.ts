import { ZonaRepository } from "./zona-repository";

export * from "./zona";
export * from "./zona-repository";

export const zona_repository = new ZonaRepository();
