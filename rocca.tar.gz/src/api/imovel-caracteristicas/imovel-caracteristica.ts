export type ImovelCaracteristica = {
    Codigo: string
    [key: string]: string
}
