import { ImovelCaracteristicaRepository } from "./imovel-caracteristica-repository";

export * from "./imovel-caracteristica";
export * from "./imovel-caracteristica-repository";

export const imovel_caracteristica_repository = new ImovelCaracteristicaRepository();
