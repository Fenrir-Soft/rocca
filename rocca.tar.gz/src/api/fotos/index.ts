import { FotoRepository } from "./foto-repository";

export * from "./foto";
export * from "./foto-repository";
export const foto_repository = new FotoRepository();
