import { ImovelRepository } from "./imovel-repository";

export * from "./imovel";
export * from "./imovel-repository";

export const imovel_repository = new ImovelRepository();
