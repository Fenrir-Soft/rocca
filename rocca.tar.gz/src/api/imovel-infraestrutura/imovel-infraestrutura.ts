export type ImovelInfraestrutura = {
    Codigo: string
    [key: string]: string
}
