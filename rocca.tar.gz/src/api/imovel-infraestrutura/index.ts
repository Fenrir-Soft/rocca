import { ImovelInfraestruturaRepository } from "./imovel-infraestrutura-repository";

export * from "./imovel-infraestrutura";
export * from "./imovel-infraestrutura-repository";

export const imovel_infraestrutura_repository = new ImovelInfraestruturaRepository();
