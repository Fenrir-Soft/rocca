import { CidadeRepository } from "./cidade-repository";

export * from "./cidade";
export * from "./cidade-repository";

export const cidade_repository = new CidadeRepository();
