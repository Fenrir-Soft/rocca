export type Bairro = {
    UF: string;
    Cidade: string;
    Bairro: string;
    slug: string;
    cidade_slug: string;
};
