export type CategoriaTipo = {
    id: number;
    slug: string;
    titulo: string;
    tipos: string[];
    ordenamento: number;
};
