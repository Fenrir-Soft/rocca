import { CategoriaTipoRepository } from "./categoria-tipo-repository";

export * from "./categoria-tipo";
export * from "./categoria-tipo-repository";

export const categoria_tipo_repository = new CategoriaTipoRepository();
