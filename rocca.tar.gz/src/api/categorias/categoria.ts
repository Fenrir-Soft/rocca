export type Categoria = {
    slug: string;
    Categoria: string;
};
