<template>
    <Imovel :imovel="imovel" :foto="fotos.get(imovel.codigo)" v-for="imovel in results" />
</template>
<script setup lang="ts">
import type { InferEntrySchema } from 'astro:content';
import Imovel from './Imovel.vue'
import { computed, ref } from 'vue';
import { bairros, codigos, finalidade, tipos } from '../../store/search-params';
import slugify from 'slugify';

interface Props {
    imoveis: InferEntrySchema<'imoveis'>[],
    fotos: InferEntrySchema<'fotos'>[]
}

const props = defineProps<Props>()

const results = computed(() => {
    return props.imoveis.filter((imovel) => {
        
        if (bairros.value.length > 0) {
            let bairro_slug = slugify(`${imovel.bairro} ${imovel.cidade} ${imovel.uf}`, {
                lower: true
            })
            let bairro_comercial_slug = slugify(`${imovel.bairro_comercial||imovel.bairro} ${imovel.cidade} ${imovel.uf}`, {
                lower: true
            })
            
            if (!bairros.value.includes(bairro_slug) && !bairros.value.includes(bairro_comercial_slug)) {
                return false
            }
        }

        if (tipos.value.length > 0) {
            let tipo_slug = slugify(imovel.categoria, {
                lower: true
            })
            if (!tipos.value.includes(tipo_slug)) {
                return false
            }
        }

        if (finalidade.value.length > 0) {
            if (finalidade.value === 'comprar' && !imovel.venda) {
                return false
            }
            if (finalidade.value === 'alugar' && !imovel.locacao) {
                return false
            }
        }
        
        if (codigos.value.length > 0) {
            if (!codigos.value.includes(`${imovel.codigo}`)) {
                return false
            }
        }

        return true
    })
})


const fotos = computed<Map<string, InferEntrySchema<'fotos'>>>(() => {
    const map: Map<string, InferEntrySchema<'fotos'>> = new Map()

    for (let foto of props.fotos) {
        map.set(foto.Codigo, foto)
    }

    return map
})

</script>